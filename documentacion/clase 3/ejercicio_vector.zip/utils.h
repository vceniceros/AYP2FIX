#ifndef _UTILS_H
#define _UTILS_H

#include <iostream>
#include <vector>
#include <cstdlib>

using namespace std;

const int CANTIDAD_INICIAL = 10;
const int MAX_NUMERO = 8;

//post: carga el vector recibido por parametro con CANTIDAD_INICIAL de numeros con valor entre 0  y MAX_NUMERO
void cargarRandom(vector<int> &numeros);

//post: imprime por pantalla los numeros que contiene el vector recibido
void mostrar(vector<int> &numeros);

//post: retorna el iterador en la posicion que se encuentra el numero buscado o vector.end() si no lo encuentra
vector<int>::iterator buscar(vector<int> &numeros, int numero);

//pre: debe recibir un numero positivo como posicion
//post: elimina el elemento en la posicion indicada
void eliminarPosicion(vector<int> &numeros, int posicion);

//post: elimina la primera aparicion del numero reibido por parametro si se encuentra presente en el vector
void eliminarNumeros(vector<int> &numeros, int numero);

#endif
