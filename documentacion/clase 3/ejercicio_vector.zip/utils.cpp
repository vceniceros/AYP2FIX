#include "utils.h"


void cargarRandom(vector<int> &numeros){
  srand ((unsigned int)time(NULL));
  for (int i = 0; i < CANTIDAD_INICIAL; i++) {
    numeros.push_back(rand() % MAX_NUMERO);
  }
}

void mostrar(vector<int> &numeros){
  cout << "Los numeros presentes son:" << endl;

  for (size_t i = 0; i < numeros.size(); i++) {
    cout << numeros[i] << " ";
  }

  cout << endl;
}

vector<int>::iterator  buscar(vector<int> &numeros, int numero){
  vector<int>::iterator iterador = numeros.begin();
  vector<int>::iterator  posicion = numeros.end();

  while (posicion == numeros.end() && iterador < numeros.cend()){
    if(*iterador == numero){
      posicion = iterador;
    }else{
      iterador++;
    }
  }

  return posicion;
}

void eliminarPosicion(vector<int> &numeros, int posicion){
  numeros.erase(numeros.begin() + posicion);
}

void eliminarNumeros(vector<int> &numeros, int numero){
  auto posicion = buscar(numeros, numero);
  if(posicion != numeros.cend()){
    numeros.erase(posicion);
  }else{
    cout << "El numero " << numero << " no se encuentra en el vector" << endl;
  }
}
