#include <iostream>
#include "utils.h"
using namespace std;

const int NUMERO_A_BUSCAR = 3;

int main() {
  vector<int> numeros;

  cargarRandom(numeros);
  mostrar(numeros);

  cout << endl;

  auto posicion = buscar(numeros, NUMERO_A_BUSCAR);
  if(posicion != numeros.cend()){
    cout << "El numero " << NUMERO_A_BUSCAR << " se encuentra en el indice: " << (posicion - numeros.cbegin()) << endl;
  }else{
    cout << "El numero " << NUMERO_A_BUSCAR << " no se encuentra en el vector" << endl;
  }

  cout << endl;

  cout << "Eliminando el 4to elemento" << endl;
  eliminarPosicion(numeros, 3);
  mostrar(numeros);

  cout << endl;

  cout << "Eliminando el numero 5 si está" << endl;
  eliminarNumeros(numeros, 5);
  mostrar(numeros);


  return 0;
}
