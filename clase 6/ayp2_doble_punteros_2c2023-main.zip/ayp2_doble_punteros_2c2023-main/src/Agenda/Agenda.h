#ifndef ALGO2_DOBLE_PUNTEROS_AGENDA_H
#define ALGO2_DOBLE_PUNTEROS_AGENDA_H

#include "Contacto.h"

class Agenda {
private:

public:
};

#endif